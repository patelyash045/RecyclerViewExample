package com.yash.recyclerexample

data class Song(val title: String, val description: String)